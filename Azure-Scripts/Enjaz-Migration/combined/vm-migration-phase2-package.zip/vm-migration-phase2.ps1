﻿param (
    [bool]$UseManagedIdentity = $false,
    [string]$TargetTenantId = "",
    [string]$TargetClientId = "",
    [string]$TargetClientSecret = "",
    [string]$TargetSubscriptionId = "",
    [string]$CsvPath = ".\vm-migration-map.csv"
)

# Authenticate to Azure
if ($UseManagedIdentity) {
    Write-Host "Logging in using Managed Identity..."
    Connect-AzAccount -Identity -Subscription $TargetSubscriptionId
} else {
    Write-Host "Logging in using Service Principal..."
    $secureSecret = ConvertTo-SecureString $TargetClientSecret -AsPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential($TargetClientId, $secureSecret)
    Connect-AzAccount -ServicePrincipal -TenantId $TargetTenantId -Credential $credential -Subscription $TargetSubscriptionId
}

# Load VM list
$vms = Import-Csv $CsvPath

# Function to process each VM
function Start-VMCreationJob {
    param($vmRow)

    Start-Job -ScriptBlock {
        param($vmRowInner, $CsvPathInner)

        Import-Module Az.Compute
        Import-Module Az.Network
        Import-Module Az.Resources

        try {
            $vmName = $vmRowInner.VMName
            $targetRg = $vmRowInner.TargetResourceGroup
            $location = "eastus"

            if (-not $vmRowInner.VhdOsUri) {
                return
            }

            # Create OS Disk
            $osDiskName = "$($vmName)-osdisk"
            $osDiskConfig = New-AzDiskConfig -Location $location -CreateOption Import -SourceUri $vmRowInner.VhdOsUri -StorageAccountId $null
            $osDisk = New-AzDisk -ResourceGroupName $targetRg -DiskName $osDiskName -Disk $osDiskConfig

            # Create Data Disks
            $dataDisks = @()
            if ($vmRowInner.VhdDataUris) {
                $uris = $vmRowInner.VhdDataUris -split ";"
                for ($i = 0; $i -lt $uris.Count; $i++) {
                    $diskConfig = New-AzDiskConfig -Location $location -CreateOption Import -SourceUri $uris[$i] -StorageAccountId $null
                    $disk = New-AzDisk -ResourceGroupName $targetRg -DiskName "$($vmName)-datadisk$i" -Disk $diskConfig
                    $dataDisks += $disk
                }
            }

            # Create NIC
            $vnet = Get-AzVirtualNetwork -ResourceGroupName $targetRg -Name $vmRowInner.TargetVnetName
            $subnet = Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $vnet -Name $vmRowInner.TargetSubnetName
            $nicParams = @{
                Name = "$($vmName)-nic"
                ResourceGroupName = $targetRg
                Location = $location
                SubnetId = $subnet.Id
            }
            if ($vmRowInner.TargetPrivateIP) {
                $nicParams["PrivateIpAddress"] = $vmRowInner.TargetPrivateIP
                $nicParams["PrivateIpAllocationMethod"] = "Static"
            }
            $nic = New-AzNetworkInterface @nicParams

            # Configure VM
            $vmConfig = New-AzVMConfig -VMName $vmName -VMSize "Standard_DS2_v2"
            if ($vmRowInner.OSType -eq "Linux") {
                $vmConfig = Set-AzVMOperatingSystem -VM $vmConfig -Linux -ComputerName $vmName -DisablePasswordAuthentication
                $vmConfig = Set-AzVMOSDisk -VM $vmConfig -ManagedDiskId $osDisk.Id -CreateOption Attach -Linux
            } else {
                $vmConfig = Set-AzVMOperatingSystem -VM $vmConfig -Windows -ComputerName $vmName -ProvisionVMAgent -EnableAutoUpdate
                $vmConfig = Set-AzVMOSDisk -VM $vmConfig -ManagedDiskId $osDisk.Id -CreateOption Attach -Windows
            }
            $vmConfig = Add-AzVMNetworkInterface -VM $vmConfig -Id $nic.Id -Primary

            # Attach data disks
            for ($i = 0; $i -lt $dataDisks.Count; $i++) {
                $vmConfig = Add-AzVMDataDisk -VM $vmConfig -Name $dataDisks[$i].Name -CreateOption Attach -ManagedDiskId $dataDisks[$i].Id -Lun $i
            }

            # Create VM
            New-AzVM -ResourceGroupName $targetRg -Location $location -VM $vmConfig

            # Update CSV status
            $allVMs = Import-Csv $CsvPathInner
            foreach ($entry in $allVMs) {
                if ($entry.VMName -eq $vmRowInner.VMName) {
                    $entry.MigrationStatus = "VM Created"
                    $entry.ErrorDetails = ""
                }
            }
            $allVMs | Export-Csv -Path $CsvPathInner -NoTypeInformation -Force
        } catch {
            $allVMs = Import-Csv $CsvPathInner
            foreach ($entry in $allVMs) {
                if ($entry.VMName -eq $vmRowInner.VMName) {
                    $entry.MigrationStatus = "Failed"
                    $entry.ErrorDetails = $_.Exception.Message
                }
            }
            $allVMs | Export-Csv -Path $CsvPathInner -NoTypeInformation -Force
        }
    } -ArgumentList $vmRow, $CsvPath
}

# Launch parallel jobs
foreach ($vm in $vms) {
    if ($vm.MigrationStatus -eq "Success" -and $vm.VhdOsUri) {
        Start-VMCreationJob -vmRow $vm
    }
}

Write-Host "All VM creation jobs started. Use Get-Job and Receive-Job to monitor."
