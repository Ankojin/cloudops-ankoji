﻿VM Migration Phase 2 Package
----------------------------

This package includes:
- vm-migration-phase2.ps1 : PowerShell script to copy disks and create VMs in target tenant
- vm-migration-map.csv : Sample CSV mapping file with required columns
- README.txt : This file

Usage:
Run vm-migration-phase2.ps1 with either Managed Identity or Service Principal credentials.

Example for Service Principal:
.\vm-migration-phase2.ps1 -UseManagedIdentity \False 
  -TargetTenantId '<tenant-id>' 
  -TargetClientId '<app-id>' 
  -TargetClientSecret '<secret>' 
  -TargetSubscriptionId '<subscription-id>' 
  -CsvPath '.\vm-migration-map.csv'

Example for Managed Identity:
.\vm-migration-phase2.ps1 -UseManagedIdentity \True 
  -TargetSubscriptionId '<subscription-id>' 
  -CsvPath '.\vm-migration-map.csv'

Monitor parallel jobs with:
Get-Job
Receive-Job -Id <job-id>

